package io.sentry.react.replay;

import android.content.Context;
import com.facebook.react.views.view.ReactViewGroup;

public class RNSentryReplayUnmask extends ReactViewGroup {
  public RNSentryReplayUnmask(Context context) {
    super(context);
  }
}
