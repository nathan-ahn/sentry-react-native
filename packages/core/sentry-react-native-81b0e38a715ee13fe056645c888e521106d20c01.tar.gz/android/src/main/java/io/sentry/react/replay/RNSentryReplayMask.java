package io.sentry.react.replay;

import android.content.Context;
import com.facebook.react.views.view.ReactViewGroup;

public class RNSentryReplayMask extends ReactViewGroup {
  public RNSentryReplayMask(Context context) {
    super(context);
  }
}
