import { withSentry } from './withSentry';

export { withSentry };

export default withSentry;
