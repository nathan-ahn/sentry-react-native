package com.swmansion.rnscreens

import androidx.fragment.app.Fragment

class ScreenStackFragment(
    contentLayoutId: Int,
) : Fragment(contentLayoutId)
