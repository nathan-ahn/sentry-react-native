export const SDK_PACKAGE_NAME = 'npm:@sentry/react-native';
export const SDK_NAME = 'sentry.javascript.react-native';
export const SDK_VERSION = '7.0.1';
