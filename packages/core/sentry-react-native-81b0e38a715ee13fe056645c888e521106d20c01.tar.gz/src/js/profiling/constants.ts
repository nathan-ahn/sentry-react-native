export const MAX_PROFILE_DURATION_MS = 30 * 1e3;
