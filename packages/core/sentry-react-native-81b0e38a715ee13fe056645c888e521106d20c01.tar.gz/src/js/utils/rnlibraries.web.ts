import type { ReactNativeLibrariesInterface } from './rnlibrariesinterface';

export const ReactNativeLibraries: ReactNativeLibrariesInterface = {};
