export const APP_START_WARM = 'app_start_warm';
export const APP_START_COLD = 'app_start_cold';

export const STALL_COUNT = 'stall_count';
export const STALL_TOTAL_TIME = 'stall_total_time';
export const STALL_LONGEST_TIME = 'stall_longest_time';
