module.exports = require('./dist/js/tools/metroconfig');
