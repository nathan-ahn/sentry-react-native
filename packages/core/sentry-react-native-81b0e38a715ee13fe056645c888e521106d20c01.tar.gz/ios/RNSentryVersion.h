#import <Foundation/Foundation.h>

extern NSString *const NATIVE_SDK_NAME;
extern NSString *const REACT_NATIVE_SDK_NAME;
extern NSString *const REACT_NATIVE_SDK_PACKAGE_NAME;
extern NSString *const REACT_NATIVE_SDK_PACKAGE_VERSION;
