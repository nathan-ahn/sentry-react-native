#import <Foundation/Foundation.h>

@class SentryId;

@interface RNSentryId : NSObject

+ (SentryId *)newId;

@end
