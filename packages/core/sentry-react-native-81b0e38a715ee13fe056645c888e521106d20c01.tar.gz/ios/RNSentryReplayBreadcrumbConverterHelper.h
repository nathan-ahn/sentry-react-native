#import <Sentry/SentryDefines.h>

@interface RNSentryReplayBreadcrumbConverterHelper : NSObject

+ (void)configureSessionReplayWithConverter;

@end
