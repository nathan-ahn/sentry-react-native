#import "RNSentryVersion.h"

NSString *const NATIVE_SDK_NAME = @"sentry.cocoa.react-native";
NSString *const REACT_NATIVE_SDK_NAME = @"sentry.javascript.react-native";
NSString *const REACT_NATIVE_SDK_PACKAGE_NAME = @"npm:@sentry/react-native";
NSString *const REACT_NATIVE_SDK_PACKAGE_VERSION = @"7.0.1";
